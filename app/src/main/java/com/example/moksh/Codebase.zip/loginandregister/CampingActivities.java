package com.example.moksh.loginandregister;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class CampingActivities extends AppCompatActivity {
   Button joinCamp;
   Button organizeCamp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camping_activities);

        joinCamp = (Button) findViewById(R.id.join_a_camp);
        joinCamp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Interested in joining a camp", Toast.LENGTH_SHORT).show();
            }
        });

        organizeCamp = (Button) findViewById(R.id.organize_a_camp);
        organizeCamp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Interested in organizing a camp", Toast.LENGTH_SHORT).show();
            }
        });




    }
}
